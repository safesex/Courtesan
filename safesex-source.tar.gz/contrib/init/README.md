Sample configuration files for:

SystemD: safesexd.service
Upstart: safesexd.conf
OpenRC:  safesexd.openrc
         safesexd.openrcconf
CentOS:  safesexd.init
OS X:    org.safesex.safesexd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
