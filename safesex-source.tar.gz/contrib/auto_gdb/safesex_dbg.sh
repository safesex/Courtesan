#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.safesexcore/safesexd.pid file instead
safesex_pid=$(<~/.safesexcore/testnet3/safesexd.pid)
sudo gdb -batch -ex "source debug.gdb" safesexd ${safesex_pid}
