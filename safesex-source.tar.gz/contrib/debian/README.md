
Debian
====================
This directory contains files used to package safesexd/safesex-qt
for Debian-based Linux systems. If you compile safesexd/safesex-qt yourself, there are some useful files here.

## safesex: URI support ##


safesex-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install safesex-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your safesex-qt binary to `/usr/bin`
and the `../../share/pixmaps/safesex128.png` to `/usr/share/pixmaps`

safesex-qt.protocol (KDE)

