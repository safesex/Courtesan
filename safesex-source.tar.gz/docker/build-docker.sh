#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR/..

DOCKER_IMAGE=${DOCKER_IMAGE:-safesexpay/safesexd-develop}
DOCKER_TAG=${DOCKER_TAG:-latest}

BUILD_DIR=${BUILD_DIR:-.}

rm docker/bin/*
mkdir docker/bin
cp $BUILD_DIR/src/safesexd docker/bin/
cp $BUILD_DIR/src/safesex-cli docker/bin/
cp $BUILD_DIR/src/safesex-tx docker/bin/
strip docker/bin/safesexd
strip docker/bin/safesex-cli
strip docker/bin/safesex-tx

docker build --pull -t $DOCKER_IMAGE:$DOCKER_TAG -f docker/Dockerfile docker
